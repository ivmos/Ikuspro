AutoComplete Readme
-------------------

* About AutoComplete

  AutoComplete is a Swing library that facilitates adding auto-completion
  (aka "code completion, "Intellisense") to any JTextComponent.  Special
  integration is added for RSyntaxTextArea (a programmer's text editor, see
  http://fifesoft.com/rsyntaxtextarea/ for more information), since this feature
  is commonly needed when editing source code.

* Example Usage

  TODO

* License

  AutoComplete is licensed under the LGPL.  Please see the included license
  file.

* Feedback

  I hope you find AutoComplete useful.  Bug reports, feature requests, and
  just general questions are always welcome.  Ways you can submit feedback:

    * http://forum.fifesoft.com (preferred)
         Has a forum for AutoComplete and related projects, where you can
         ask questions and get feedback quickly.

    * http://fifesoft.com/autocomplete
         Project home page, which contains general information and example
         source code.
