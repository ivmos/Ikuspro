/*
 * 12/21/2004
 *
 * ConfigurableCaret.java - The caret used by RTextArea.
 * Copyright (C) 2004 Robert Futrell
 * robert_futrell at users.sourceforge.net
 * http://fifesoft.com/rsyntaxtextarea
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA.
 */
package org.fife.ui.rtextarea;

import java.awt.*;
import java.awt.event.*;
import java.awt.datatransfer.*;
import java.beans.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.plaf.*;
import javax.swing.text.*;
import java.util.EventListener; 


/**
 * The caret used by <code>RTextArea</code>.  This caret has all of the
 * properties that <code>javax.swing.text.DefaultCaret</code> does, as
 * well as adding the following nicities:
 *
 * <ul>
 *   <li>This caret can paint itself several different ways:
 *      <ol>
 *         <li>As a vertical line (like <code>DefaultCaret</code>)</li>
 *         <li>As an underline</li>
 *         <li>As a "block caret"</li>
 *         <li>As a rectangle around the current character</li>
 *      </ol></li>
 *   <li>On Microsoft Windows and other operating systems that do not
 *       support system selection (i.e., selecting text, then pasting
 *       via the middle mouse button), clicking the middle mouse button
 *       will cause a regular paste operation to occur.  On systems
 *       that support system selection (i.e., all UNIX variants),
 *       the middle mouse button will behave normally.</li>
 *   <li>The caret moves to the undo/redo location when an undo or
 *       redo occurs (<code>DefaultCaret</code> doesn't do this
 *       in J2SE1.4.x but does in 1.5+).</li>
 * </ul>
 *
 * @author Robert Futrell
 * @version 0.5
 */
public class ConfigurableCaret extends Rectangle
		implements Caret, FocusListener, MouseListener, MouseMotionListener {

	/**
	 * The minimum value of a caret style.
	 */
	public static final int MIN_STYLE				= 0;

	/**
	 * The vertical line style.
	 */
	public static final int VERTICAL_LINE_STYLE		= 0;

	/**
	 * The horizontal line style.
	 */
	public static final int UNDERLINE_STYLE			= 1;

	/**
	 * The block style.
	 */
	public static final int BLOCK_STYLE			= 2;

	/**
	 * The block border style.
	 */
	public static final int BLOCK_BORDER_STYLE		= 3;

	/**
	 * The maximum value of a caret style.
	 */
	public static final int MAX_STYLE				= BLOCK_BORDER_STYLE;


	/**
	 * The event listener list.
	 */
	protected EventListenerList listenerList = new EventListenerList();

	/**
	 * The change event for the model.
	 * Only one ChangeEvent is needed per model instance since the
	 * event's only (read-only) state is the source property.  The source
	 * of events generated here is always "this".
	 */
	protected transient ChangeEvent changeEvent = null;

	private RTextArea component;

	boolean visible;
	boolean active;
	int dot;
	int mark;
	List selectionTagList;
	boolean selectionVisible;
	Timer flasher;
	Point magicCaretPosition;
	Object selectionTag;
	transient Handler handler = new Handler();
	private transient NavigationFilter.FilterBypass filterBypass;
	static private transient Action selectWord = null;
	static private transient Action selectLine = null;

	/**
	 * This is used to indicate if the caret currently owns the selection.
	 * This is always false if the system does not support the system
	 * clipboard.
	 */
	private boolean ownsSelection;

	/**
	 * If this is true, the location of the dot is updated regardless of
	 * the current location. This is set in the DocumentListener
	 * such that even if the model location of dot hasn't changed (perhaps do
	 * to a forward delete) the visual location is updated.
	 */
	private boolean forceCaretPositionChange;

	/**
	 * Whether or not mouseReleased should adjust the caret and focus.
	 * This flag is set by mousePressed if it wanted to adjust the caret
	 * and focus but couldn't because of a possible DnD operation.
	 */
	private transient boolean shouldHandleRelease;

	/**
	 * holds last MouseEvent which caused the word selection
	 */
	private transient MouseEvent selectedWordEvent = null;

	/**
	 * Used for fastest-possible retrieval of the character at the
	 * caret's position in the document.
	 */
	private Segment seg;

	/**
	 * Whether the caret is a vertical line, a horizontal line, or a block.
	 */
	private int style;

	/**
	 * The selection painter.  By default this paints selections with the
	 * text area's selection color.
	 */
	private Highlighter.HighlightPainter selectionPainter;


	/**
	 * Creates the caret using <code>VERTICAL_LINE_STYLE</code>.
	 */
	public ConfigurableCaret() {
		this(VERTICAL_LINE_STYLE);
	}


	/**
	 * Constructs a new <code>ConfigurableCaret</code>.
	 *
	 * @param style The style to use when painting the caret.  If this isn't
	 *        one of <code>VERTICAL_LINE_STYLE</code>,
	 *        <code>UNDERLINE_STYLE</code>, or <code>BLOCK_STYLE</code>,
	 *        then <code>VERTICAL_LINE_STYLE</code> is used.
	 */
	public ConfigurableCaret(int style) {
		seg = new Segment();
		setStyle(style);
		selectionPainter = new ChangableHighlightPainter();
	}


	/**
	 * Adds a listener to track whenever the caret position has
	 * been changed.
	 *
	 * @param l the listener
	 * @see Caret#addChangeListener
	 */
	public void addChangeListener(ChangeListener l) {
		listenerList.add(ChangeListener.class, l);
	}


	/**
	 * Adjusts the caret location based on the MouseEvent.
	 */
	private void adjustCaret(MouseEvent e) {
		if ((e.getModifiers()&ActionEvent.SHIFT_MASK)!=0 && getDot()!=-1)
			moveCaret(e);
		else
			positionCaret(e);
	}


	void adjustCaretAndFocus(MouseEvent e) {
		adjustCaret(e);
		adjustFocus(false);
	}


	/**
	 * Adjusts the focus, if necessary.
	 *
	 * @param inWindow if true indicates requestFocusInWindow should be used
	 */
	private void adjustFocus(boolean inWindow) {
		if ((component != null) && component.isEnabled() &&
				component.isRequestFocusEnabled()) {
			if (inWindow)
				component.requestFocusInWindow();
			else 
				component.requestFocus();
		}
	}


	/**
	 * Scrolls the associated view (if necessary) to make
	 * the caret visible.  Since how this should be done
	 * is somewhat of a policy, this method can be 
	 * reimplemented to change the behavior.  By default
	 * the scrollRectToVisible method is called on the
	 * associated component.
	 *
	 * @param nloc the new position to scroll to
	 */
	protected void adjustVisibility(Rectangle nloc) {
		if(component == null)
			return;
		if (SwingUtilities.isEventDispatchThread())
			component.scrollRectToVisible(nloc);
		else
			SwingUtilities.invokeLater(new SafeScroller(nloc));
	}


	/**
	 * Sets the caret position (dot) to a new location.  This
	 * causes the old and new location to be repainted.  It
	 * also makes sure that the caret is within the visible 
	 * region of the view, if the view is scrollable.
	 */
	void changeCaretPosition(int dot) {

		// repaint the old position and set the new value of
		// the dot.
		repaint();

		// Make sure the caret is visible if this window has the focus.
		if (flasher != null && flasher.isRunning()) {
			visible = true;
			flasher.restart();
		}

		// notify listeners at the caret moved
		this.dot = dot;
		fireStateChanged();

		updateSystemSelection();

		setMagicCaretPosition(null);

		// We try to repaint the caret later, since things
		// may be unstable at the time this is called 
		// (i.e. we don't want to depend upon notification
		// order or the fact that this might happen on
		// an unsafe thread).
		Runnable callRepaintNewCaret = new Runnable() {
			public void run() {
				repaintNewCaret();
			}
		};
		SwingUtilities.invokeLater(callRepaintNewCaret);

	}


	/**
	 * Damages the area surrounding the caret to cause it to be repainted in
	 * a new location.  If <code>paint()</code> is reimplemented, this method
	 * should also be reimplemented.  This method should update the caret
	 * bounds (x, y, width, and height).
	 *
	 * @param r  the current location of the caret
	 * @see #paint
	 */
	protected synchronized void damage(Rectangle r) {
		if (r != null) {
			x = r.x - 1;
			y = r.y;
			width = r.width + 4;
			height = r.height;
			repaint();
		}
	}


	/**
	 * Called when the UI is being removed from the
	 * interface of a JTextComponent.  This is used to
	 * unregister any listeners that were attached.
	 *
	 * @param c The text component.  If this is not an
	 *        <code>RTextArea</code>, an <code>Exception</code>
	 *        will be thrown.
	 * @see Caret#deinstall
	 */
	public void deinstall(JTextComponent c) {
		if (!(c instanceof RTextArea))
			throw new IllegalArgumentException(
					"c must be instance of RTextArea");
		c.removeMouseListener(this);
		c.removeMouseMotionListener(this);
		c.removeFocusListener(this);
		c.removePropertyChangeListener(handler);
		Document doc = c.getDocument();
		if (doc != null)
			doc.removeDocumentListener(handler);
		synchronized(this) {
			component = null;
		}
		if (flasher != null)
			flasher.stop();
	}


	/**
	 * This is invoked after the document changes to verify the current
	 * dot/mark is valid. We do this in case the <code>NavigationFilter</code>
	 * changed where to position the dot, that resulted in the current location
	 * being bogus.
	 */
	private void ensureValidPosition() {
		int length = component.getDocument().getLength();
		if (dot > length || mark > length) {
			// Current location is bogus and filter likely vetoed the
			// change, force the reset without giving the filter a
			// chance at changing it.
			handleSetDot(length);
		}
	}


	/**
	 * Compares this object to the specified object.
	 * The superclass behavior of comparing rectangles
	 * is not desired, so this is changed to the Object
	 * behavior.
	 *
	 * @param     obj   the object to compare this font with
	 * @return    <code>true</code> if the objects are equal; 
	 *            <code>false</code> otherwise
	 */
	public boolean equals(Object obj) {
		return (this == obj);
	}


	/**
	 * Notifies all listeners that have registered interest for
	 * notification on this event type.  The event instance 
	 * is lazily created using the parameters passed into 
	 * the fire method.  The listener list is processed last to first.
	 *
	 * @see EventListenerList
	 */
	protected void fireStateChanged() {
		// Guaranteed to return a non-null array
		Object[] listeners = listenerList.getListenerList();
		// Process the listeners last to first, notifying
		// those that are interested in this event
		for (int i = listeners.length-2; i>=0; i-=2) {
			if (listeners[i]==ChangeListener.class) {
				// Lazily create the event:
				if (changeEvent == null)
					changeEvent = new ChangeEvent(this);
				((ChangeListener)listeners[i+1]).stateChanged(changeEvent);
			}
		}
	}	


	/**
	 * Called when the component containing the caret gains
	 * focus.  This is implemented to set the caret to visible
	 * if the component is editable.
	 *
	 * @param e the focus event
	 * @see FocusListener#focusGained
	 */
	public void focusGained(FocusEvent e) {
		if (component.isEnabled()) {
			if (component.isEditable())
				setVisible(true);
			setSelectionVisible(true);
		}
	}


	/**
	 * Called when the component containing the caret loses
	 * focus.  This is implemented to set the caret to visibility
	 * to false.
	 *
	 * @param e the focus event
	 * @see FocusListener#focusLost
	 */
	public void focusLost(FocusEvent e) {
		setVisible(false);
		setSelectionVisible(ownsSelection || e.isTemporary());
	}


	/**
	 * Gets the caret blink rate.
	 *
	 * @return the delay in milliseconds.  If this is
	 *  zero the caret will not blink.
	 * @see Caret#getBlinkRate
	 */
	public int getBlinkRate() {
		return (flasher==null) ? 0 : flasher.getDelay();
	}


	/**
	 * Returns an array of all the change listeners
	 * registered on this caret.
	 *
	 * @return all of this caret's <code>ChangeListener</code>s 
	 *         or an empty
	 *         array if no change listeners are currently registered
	 *
	 * @see #addChangeListener
	 * @see #removeChangeListener
	 */
	public ChangeListener[] getChangeListeners() {
		return (ChangeListener[])listenerList.getListeners(
								ChangeListener.class);
	}


	private ClipboardOwner getClipboardOwner() {
		return handler;
	}


	/**
	 * Gets the text editor component that this caret is bound to.
	 *
	 * @return The <code>RTextArea</code>.
	 */
	protected RTextArea getTextArea() {
		return component;
	}


	/**
	 * Fetches the current position of the caret.
	 *
	 * @return the position >= 0
	 * @see Caret#getDot
	 */
	public int getDot() {
		return dot;
	}


	private NavigationFilter.FilterBypass getFilterBypass() {
		if (filterBypass == null)
			filterBypass = new DefaultFilterBypass();
		return filterBypass;
	}


	/**
	 * Returns an array of all the objects currently registered
	 * as <code><em>Foo</em>Listener</code>s
	 * upon this caret.
	 * <code><em>Foo</em>Listener</code>s are registered using the
	 * <code>add<em>Foo</em>Listener</code> method.
	 *
	 * @param listenerType the type of listeners requested; this parameter
	 *        should specify an interface that descends from
	 *        <code>java.util.EventListener</code>
	 * @return An array of all objects registered as
	 *         <code><em>Foo</em>Listener</code>s on this component, or an
	 *         empty array if no such listeners have been added.
	 * @see #getChangeListeners
	 */
	public EventListener[] getListeners(Class listenerType) { 
		return listenerList.getListeners(listenerType); 
	}


	/**
	 * Gets the saved caret position.
	 *
	 * @return the position
	 * see #setMagicCaretPosition
	 */
	public Point getMagicCaretPosition() {
		return magicCaretPosition;
	}


	/**
	 * Fetches the current position of the mark.  If there is a selection,
	 * the dot and mark will not be the same.
	 *
	 * @return the position >= 0
	 * @see Caret#getMark
	 */
	public int getMark() {
		return mark;
	}


	/**
	 * Returns whether this caret's selection uses rounded edges.
	 *
	 * @return Whether this caret's edges are rounded.
	 * @see #setRoundedSelectionEdges
	 */
	public boolean getRoundedSelectionEdges() {
		return ((ChangableHighlightPainter)getSelectionPainter()).
								getRoundedEdges();
	}


	/**
	 * Gets the painter for the Highlighter.
	 *
	 * @return the painter
	 */
	protected Highlighter.HighlightPainter getSelectionPainter() {
		return selectionPainter;
	}


	/**
	 * Gets the current style of this caret.
	 *
	 * @return The caret's style.
	 * @see #setStyle
	 */
	public int getStyle() {
		return style;
	}


	private Clipboard getSystemSelection() {
		try {
			return component.getToolkit().getSystemSelection();
		} catch (HeadlessException he) {
			// do nothing... there is no system clipboard
		} catch (SecurityException se) {
			// do nothing... there is no allowed system clipboard
		}
		return null;
	}


	/**
	 * Actually does the dirty work of moving the dot.  Handles block
	 * selections as well.
	 *
	 * @param dot The new location for the dot.
	 */
	protected void handleMoveDot(int dot) {

		changeCaretPosition(dot);

		if (selectionVisible) {
			Highlighter h = component.getHighlighter();
			if (h != null) {
				int p0 = Math.min(dot, mark);
				int p1 = Math.max(dot, mark);
	
				// if p0 == p1 then there should be no highlight, remove it
				// if necessary.
				if (p0 == p1) {
					if (selectionTag != null) {
						h.removeHighlight(selectionTag);
						selectionTag = null;
					}
				}
				// otherwise, change or add the highlight
				else {
					try {
						if (selectionTag != null) {
							h.changeHighlight(selectionTag, p0, p1);
						}
						else {
							Highlighter.HighlightPainter p = getSelectionPainter();
							selectionTag = h.addHighlight(p0, p1, p);
						}
					} catch (BadLocationException e) {
						throw new InternalError("Bad caret position");
					}
				}
			} // End of if (h != null).
		} // End of if (selectionVisible).

	}


	/**
	 * Handles the dirty-work of setting the dot location.
	 *
	 * @param dot The new dot location.
	 */
	protected void handleSetDot(int dot) {

		// Move the dot, if it changed locations.
		Document doc = component.getDocument();
		if (doc != null)
			dot = Math.min(dot, doc.getLength());
		dot = Math.max(dot, 0);

		mark = dot;
		if (this.dot != dot || selectionTag != null ||
				forceCaretPositionChange) {
			changeCaretPosition(dot);
		}
		Highlighter h = component.getHighlighter();
		if ((h != null) && (selectionTag != null)) {
			h.removeHighlight(selectionTag);
			selectionTag = null;
		}

	}


	/**
	 * Called when the UI is being installed into the interface of a
	 * JTextComponent.  This can be used to gain access to the model
	 * that is being navigated by the implementation of this interface.
	 * Sets the dot and mark to 0, and establishes document, property
	 * change, focus, mouse, and mouse motion listeners.
	 *
	 * @param c The text component.  If this is not an <code>RTextArea</code>,
	 *        an <code>Exception</code> will be thrown.
	 * @see Caret#install
	 */
	public void install(JTextComponent c) {

		if (!(c instanceof RTextArea))
			throw new IllegalArgumentException(
					"c must be instance of RTextArea");
		component = (RTextArea)c;
		Document doc = c.getDocument();
		dot = mark = 0;
		if (doc != null)
			doc.addDocumentListener(handler);
		c.addPropertyChangeListener(handler);
		c.addFocusListener(this);
		c.addMouseListener(this);
		c.addMouseMotionListener(this);

		// if the component already has focus, it won't
		// be notified.
		if (component.hasFocus())
			focusGained(null);

	}


	/**
	 * Determines if the caret is currently active.
	 * <p>
	 * This method returns whether or not the <code>Caret</code> is currently
	 * in a blinking state. It does not provide information as to whether it
	 * is currently blinked on or off.  To determine if the caret is currently
	 * use the <code>isVisible</code> method.
	 *
	 * @return <code>true</code> if active else <code>false</code>
	 * @see #isVisible
	 */
	public boolean isActive() {
		return active;
	}


	/**
	 * Checks whether the current selection is visible.
	 *
	 * @return true if the selection is visible
	 */
	public boolean isSelectionVisible() {
		return selectionVisible;
	}


	/**
	 * Indicates whether or not the caret is currently visible. As the
	 * caret flashes on and off the return value of this will change
	 * between true, when the caret is painted, and false, when the
	 * caret is not painted. <code>isActive</code> indicates whether
	 * or not the caret is in a blinking state, such that it <b>can</b>
	 * be visible, and <code>isVisible</code> indicates whether or not
	 * the caret <b>is</b> actually visible.
	 * <p>
	 * Subclasses that wish to render a different flashing caret should
	 * override paint and only paint the caret if this method returns true.
	 *
	 * @return true if visible else false
	 * @see Caret#isVisible
	 * @see #isActive
	 */
	public boolean isVisible() {
		return visible;
	}


	/**
	 * Called when the mouse is clicked.  If the click was generated from
	 * button1, a double click selects a word, and a triple click the
	 * current line.
	 *
	 * @param e the mouse event
	 * @see MouseListener#mouseClicked
	 */
	public void mouseClicked(MouseEvent e) {
		if (! e.isConsumed()) {
			int nclicks = e.getClickCount();
			if (SwingUtilities.isLeftMouseButton(e)) {
				if (nclicks>1)
					nclicks = 2 + (nclicks%2); // Alternate selecting word/line.
				switch (nclicks) {
					case 1:
						selectedWordEvent = null;
						break;
					case 2:
						selectWord(e);
						selectedWordEvent = null;
						break;
					case 3:
						Action a = null;
						ActionMap map = component.getActionMap();
						if (map != null)
							a = map.get(RTextAreaEditorKit.selectLineAction);
						if (a == null) {
							if (selectLine == null)
								selectLine = new RTextAreaEditorKit.SelectLineAction();
							a = selectLine;
						}
						a.actionPerformed(new ActionEvent(component,
									ActionEvent.ACTION_PERFORMED,
									null, e.getWhen(), e.getModifiers()));
				} // End of switch (nclicks).
			}
			else if (SwingUtilities.isMiddleMouseButton(e)) {
				if (nclicks == 1 && component.isEditable() && component.isEnabled()) {
					// Paste the system selection, if it exists (e.g., on UNIX
					// platforms, the user can select text, the middle-mouse click
					// to paste it; this doesn't work on Windows).  If the system
					// doesn't support system selection, just do a normal paste.
					JTextComponent c = (JTextComponent) e.getSource();
					if (c != null) {
						try {
							Toolkit tk = c.getToolkit();
							Clipboard buffer = tk.getSystemSelection();
							// If the system supports system selections, (e.g. UNIX),
							// try to do it.
							if (buffer != null) {
								adjustCaret(e);
								TransferHandler th = c.getTransferHandler();
								if (th != null) {
									Transferable trans = buffer.getContents(null);
									if (trans != null)
										th.importData(c, trans);
								}
								adjustFocus(true);
							}
							// If the system doesn't support system selections
							// (e.g. Windows), just do a normal paste.
							else {
								component.paste();
							}
						} catch (HeadlessException he) {
							// do nothing... there is no system clipboard
						}
					} // if (c!=null)
				} // if (nclicks == 1 && component.isEditable() && component.isEnabled())
			} // else if (SwingUtilities.isMiddleMouseButton(e))
		} // if (!c.isConsumed())
	}


	/**
	 * Moves the caret position according to the mouse pointer's
	 * current location.  This effectively extends the selection.
	 * By default, this is only done for mouse button 1.
	 *
	 * @param e the mouse event
	 * @see MouseMotionListener#mouseDragged
	 */
	public void mouseDragged(MouseEvent e) {
		if ((! e.isConsumed()) && SwingUtilities.isLeftMouseButton(e)) {
			moveCaret(e);
		}
	}


	/**
	 * Called when the mouse enters a region.
	 *
	 * @param e the mouse event
	 * @see MouseListener#mouseEntered
	 */
	public void mouseEntered(MouseEvent e) {
	}


	/**
	 * Called when the mouse exits a region.
	 *
	 * @param e the mouse event
	 * @see MouseListener#mouseExited
	 */
	public void mouseExited(MouseEvent e) {
	}


	/**
	 * Called when the mouse is moved.
	 *
	 * @param e the mouse event
	 * @see MouseMotionListener#mouseMoved
	 */
	public void mouseMoved(MouseEvent e) {
	}


	/**
	 * If button 1 is pressed, this is implemented to request focus on the
	 * associated text component, and to set the caret position.  If the shift
	 * key is held down, the caret will be moved, potentially resulting in a
	 * selection, otherwise the caret position will be set to the new location.
	 * If the component is not enabled, there will be no request for focus.
	 *
	 * @param e the mouse event
	 * @see MouseListener#mousePressed
	 */
	public void mousePressed(MouseEvent e) {
		if (SwingUtilities.isLeftMouseButton(e)) {
			if (e.isConsumed()) {
				shouldHandleRelease = true;
			}
			else {
				shouldHandleRelease = false;
				adjustCaretAndFocus(e);
				if (e.getClickCount() == 2) {
					selectWord(e);
				}
			}
		}
	}


	/**
	 * Called when a mouse button is released.
	 *
	 * @param e the mouse event
	 * @see MouseListener#mouseReleased
	 */
	public void mouseReleased(MouseEvent e) {
		if (shouldHandleRelease && SwingUtilities.isLeftMouseButton(e)) {
			adjustCaretAndFocus(e);
		}
	}


	/**
	 * Tries to move the position of the caret from the coordinates of a
	 * mouse event, using viewToModel().  This will cause a selection if
	 * the dot and mark are different.
	 *
	 * @param e the mouse event
	 */
	protected void moveCaret(MouseEvent e) {
		Point pt = new Point(e.getX(), e.getY());
		int pos = component.getUI().viewToModel(component, pt);
		moveDot(pos);
	}


	/**
	 * Moves the caret position to some other position.
	 *
	 * @param dot the position >= 0
	 * @see Caret#moveDot
	 */
	public void moveDot(int dot) {
		// don't allow selection on disabled components.
		if (!component.isEnabled()) {
			setDot(dot);
			return;
		}
		if (dot!=this.dot) {
			NavigationFilter filter = component.getNavigationFilter();	
			if (filter != null)
		 		filter.moveDot(getFilterBypass(), dot, Position.Bias.Forward);
			else
		 		handleMoveDot(dot);
		}
	}


	/**
	 * Paints the cursor.
	 *
	 * @param g The graphics context in which to paint.
	 */
	public void paint(Graphics g) {

		// If the cursor is currently visible...
		if (isVisible()) {

			try {

				g.setColor(component.getCaretColor());
				TextUI mapper = component.getUI();
				Rectangle r = mapper.modelToView(component, dot);

				// "Correct" the value of rect.width (takes into
				// account caret being at EOL (and thus rect.width==1),
				// etc.
				// We do this even for LINE_STYLE because
				// if they change from that caret to block/underline,
				// the first time they do so width==1, so it will take
				// one caret flash to paint correctly (wider).  If we
				// do this every time, then it's painted correctly the
				// first blink.
				validateWidth(r);

				// Need to subtract 2 from height, otherwise
				// the caret will expand too far vertically.
				r.height -= 2;

				switch (style) {

					// Draw a big rectangle, and xor the foreground color.
					case BLOCK_STYLE:
						g.setXORMode(Color.WHITE);
						// fills x==r.x to x==(r.x+(r.width)-1), inclusive.
						g.fillRect(r.x,r.y, r.width,r.height);
						break;

					// Draw a rectangular border.
					case BLOCK_BORDER_STYLE:
						// fills x==r.x to x==(r.x+(r.width-1)), inclusive.
						g.drawRect(r.x,r.y, r.width-1,r.height);
						break;

					// Draw an "underline" below the current position.
					case UNDERLINE_STYLE:
						g.setXORMode(Color.WHITE);
						int y = r.y + r.height;
						g.drawLine(r.x,y, r.x+r.width-1,y);
						break;

					// Draw a vertical line.
					default:
						g.drawLine(r.x,r.y, r.x,r.y+r.height);

				} // End of switch (style).

			} catch (BadLocationException ble) {
				ble.printStackTrace();
			}

		} // End of if (isVisible()).

	}


	/**
	 * Tries to set the position of the caret from
	 * the coordinates of a mouse event, using viewToModel().
	 *
	 * @param e the mouse event
	 */
	protected void positionCaret(MouseEvent e) {
		Point pt = new Point(e.getX(), e.getY());
		int pos = component.getUI().viewToModel(component, pt);
		setDot(pos);
	}


	private void readObject(ObjectInputStream s)
						throws ClassNotFoundException, IOException {
		s.defaultReadObject();
		setStyle(s.readInt());
		handler = new Handler();
	}


	/**
	 * Removes a listener that was tracking caret position changes.
	 *
	 * @param l the listener
	 * @see Caret#removeChangeListener
	 */
	public void removeChangeListener(ChangeListener l) {
		listenerList.remove(ChangeListener.class, l);
	}


	/**
	 * Cause the caret to be painted.  The repaint
	 * area is the bounding box of the caret (i.e.
	 * the caret rectangle or <em>this</em>).
	 * <p>
	 * This method is thread safe, although most Swing methods
	 * are not. Please see 
	 * <A HREF="http://java.sun.com/products/jfc/swingdoc-archive/threads.html">
	 * Threads and Swing</A> for more information.
	 */
	protected final synchronized void repaint() {
		if (component != null)
			component.repaint(x, y, width, height);
	}


	/**
	 * Repaints the new caret position, with the
	 * assumption that this is happening on the
	 * event thread so that calling <code>modelToView</code>
	 * is safe.
	 */
	void repaintNewCaret() {

		if (component != null) {

			TextUI mapper = component.getUI();
			Document doc = component.getDocument();

			if ((mapper != null) && (doc != null)) {

				// determine the new location and scroll if
				// not visible.
				Rectangle newLoc;
				try {
					newLoc = mapper.modelToView(component, this.dot);
					validateWidth(newLoc);
				} catch (BadLocationException e) {
					newLoc = null;
				}
				if (newLoc != null) {
					adjustVisibility(newLoc);
					// If there is no magic caret position, make one
					if (getMagicCaretPosition() == null)
						setMagicCaretPosition(new Point(newLoc.x, newLoc.y));
				}
	
				// repaint the new position
				damage(newLoc);

			}

		} // End of if (component != null).

	}


	/**
	 * Selects word based on the MouseEvent
	 */
	private void selectWord(MouseEvent e) {
		if (selectedWordEvent != null
				&& selectedWordEvent.getX() == e.getX()
				&& selectedWordEvent.getY() == e.getY()) {
			// We've already the done selection for this.
			return;
		}
		Action a = null;
		ActionMap map = component.getActionMap();
		if (map != null)
			a = map.get(RTextAreaEditorKit.selectWordAction);
		if (a == null) {
			if (selectWord == null)
				selectWord = new RTextAreaEditorKit.SelectWordAction();
			a = selectWord;
		}
		a.actionPerformed(new ActionEvent(component,
							ActionEvent.ACTION_PERFORMED,
							null, e.getWhen(), e.getModifiers()));
		selectedWordEvent = e;
	}


	/**
	 * Sets the caret blink rate.
	 *
	 * @param rate the rate in milliseconds, 0 to stop blinking
	 * @see Caret#setBlinkRate
	 */
	public void setBlinkRate(int rate) {
		if (rate != 0) {
			if (flasher == null)
				flasher = new Timer(rate, handler);
			flasher.setDelay(rate);
		}
		else {
			if (flasher != null) {
				flasher.stop();
				flasher.removeActionListener(handler);
				flasher = null;
			}
		}
	}


	/**
	 * Sets the caret position and mark to some position.  This
	 * implicitly sets the selection range to zero.
	 *
	 * @param dot the position >= 0
	 * @see Caret#setDot
	 */
	public void setDot(int dot) {
		NavigationFilter filter = component.getNavigationFilter();
		if (filter != null)
		  filter.setDot(getFilterBypass(), dot, Position.Bias.Forward);
		else
		  handleSetDot(dot);
	}


	/**
	 * Saves the current caret position.  This is used when 
	 * caret up/down actions occur, moving between lines
	 * that have uneven end positions.
	 *
	 * @param p the position
	 * @see #getMagicCaretPosition
	 */
	public void setMagicCaretPosition(Point p) {
		magicCaretPosition = p;
	}


	/**
	 * Sets whether this caret's selection should have rounded edges.
	 *
	 * @param rounded Whether it should have rounded edges.
	 * @see #getRoundedSelectionEdges
	 */
	public void setRoundedSelectionEdges(boolean rounded) {
		((ChangableHighlightPainter)getSelectionPainter()).
								setRoundedEdges(rounded);
	}


	/**
	 * Changes the selection visibility.
	 *
	 * @param vis the new visibility
	 */
	public void setSelectionVisible(boolean vis) {

		if (vis != selectionVisible) {

			selectionVisible = vis;

			if (selectionVisible) {
				Highlighter h = component.getHighlighter();
				if ((dot != mark) && (h != null) && (selectionTag == null)) {
					int p0 = Math.min(dot, mark);
					int p1 = Math.max(dot, mark);
					Highlighter.HighlightPainter p = getSelectionPainter();
					try {
						selectionTag = h.addHighlight(p0, p1, p);
					} catch (BadLocationException bl) {
						selectionTag = null;
					}
				}
			}
			else {
				if (selectionTag != null) {
					Highlighter h = component.getHighlighter();
					h.removeHighlight(selectionTag);
					selectionTag = null;
				}
			}

		} // End of if (vis != selectionVisible).

	}


	/**
	 * Sets the style used when painting the caret.
	 *
	 * @param style The style to use.  If this isn't one of
	 *        <code>VERTICAL_LINE_STYLE</code>, <code>UNDERLINE_STYLE</code>,
	 *        or <code>BLOCK_STYLE</code>, then
	 *        <code>VERTICAL_LINE_STYLE</code> is used.
	 * @see #getStyle
	 */
	public void setStyle(int style) {
		if (style<MIN_STYLE || style>MAX_STYLE)
			style = VERTICAL_LINE_STYLE;
		this.style = style;
		// Make sure the caret is visible if this window has the focus.
		if (flasher != null && flasher.isRunning()) {
			visible = true;
			flasher.restart();
		}
		repaint();
	}


	/**
	 * Sets the caret visibility, and repaints the caret.
	 * It is important to understand the relationship between this method,
	 * <code>isVisible</code> and <code>isActive</code>.
	 * Calling this method with a value of <code>true</code> activates the
	 * caret blinking. Setting it to <code>false</code> turns it completely
	 * off.  To determine whether the blinking is active, you should call
	 * <code>isActive</code>. In effect, <code>isActive</code> is an
	 * appropriate corresponding "getter" method for this one.
	 * <code>isVisible</code> can be used to fetch the current
	 * visibility status of the caret, meaning whether or not it is currently
	 * painted. This status will change as the caret blinks on and off.
	 * <p>
	 * Here's a list showing the potential return values of both
	 * <code>isActive</code> and <code>isVisible</code>
	 * after calling this method:
	 * <p>
	 * <b><code>setVisible(true)</code></b>:
	 * <ul>
	 *     <li>isActive(): true</li>
	 *     <li>isVisible(): true or false depending on whether
	 *         or not the caret is blinked on or off</li>
	 * </ul>
	 * <p>
	 * <b><code>setVisible(false)</code></b>:
	 * <ul>
	 *     <li>isActive(): false</li>
	 *     <li>isVisible(): false</li>
	 * </ul>
	 *
	 * @param e the visibility specifier
	 * @see #isActive
	 * @see Caret#setVisible
	 */
	public void setVisible(boolean e) {

		// focus lost notification can come in later after the
		// caret has been deinstalled, in which case the component
		// will be null.
		if (component != null) {

			active = e;
			TextUI mapper = component.getUI();

			if (visible != e) {
				visible = e;
				// repaint the caret
				try {
					Rectangle loc = mapper.modelToView(component, dot);
					validateWidth(loc);
					damage(loc);
				} catch (BadLocationException badloc) {
					// hmm... not legally positioned
				}
			}

		} // End of if (component != null).

		if (flasher != null) {
			if (visible)
				flasher.start();
			else
				flasher.stop();
		}

	}


	public String toString() {
		String s = "Dot=" + dot;
		s += " Mark=" + mark;
		return s;
    }


	private void updateSystemSelection() {
		if (this.dot!=this.mark && component!=null) {
			Clipboard clip = getSystemSelection();
			if (clip != null) {
				String selectedText = null;
				selectedText = component.getSelectedText();
				clip.setContents(new StringSelection(selectedText),
								getClipboardOwner());
				ownsSelection = true;
			}
		}
	}


	/**
	 * Helper function used by the block and underline carets to ensure the
	 * width of the painted caret is valid.  This is done for the following
	 * reasons:
	 *
	 * <ul>
	 *   <li>The <code>View</code> classes in the javax.swing.text package
	 *       always return a width of "1" when <code>modelToView</code> is
	 *       called.  We'll be needing the actual width.</li>
	 *   <li>Even in smart views, such as <code>RSyntaxTextArea</code>'s
	 *       <code>SyntaxView</code> and <code>WrappedSyntaxView</code> that
	 *       return the width of the current character, if the caret is at the
	 *       end of a line for example, the width returned from
	 *       <code>modelToView</code> will be 0 (as the width of unprintable
	 *       characters such as '\n' is calculated as 0).  In this case, we'll
	 *       use a default width value.</li>
	 * </ul>
	 *
	 * @param rect The rectangle returned by the current
	 *        <code>View</code>'s <code>modelToView</code>
	 *        method for the caret position.
	 */
	private final void validateWidth(Rectangle rect) {

		// If the width value > 1, we assume the View is
		// a "smart" view that returned the proper width.
		// So only worry about this stuff if width <= 1.
		if (rect!=null && rect.width<=1) {

			// The width is either 1 (most likely, we're using a "dumb" view
			// like those in javax.swing.text) or 0 (most likely, we're using
			// a "smart" view like org.fife.ui.rsyntaxtextarea.SyntaxView,
			// we're at the end of a line, and the width of '\n' is being
			// computed as 0).

			try {

				// Try to get a width for the character at the caret
				// position.  We use the text area's font instead of g's
				// because g's may vary in an RSyntaxTextArea.
				component.getDocument().getText(dot,1, seg);
				Font font = component.getFont();
				FontMetrics fm = component.getFontMetrics(font);
				rect.width = fm.charWidth(seg.array[seg.offset]);

				// This width being returned 0 likely means that it is an
				// unprintable character (which is almost 100% to be a
				// newline char, i.e., we're at the end of a line).  So,
				// just use the width of a space.
				if (rect.width==0) {
					rect.width = fm.charWidth(' ');
				}

			} catch (BadLocationException ble) {
				// This shouldn't ever happen.
				ble.printStackTrace();
				rect.width = 8;
			}

		} // End of if (rect.width<=1).

	}


	private void writeObject(ObjectOutputStream s) throws IOException {
		s.defaultWriteObject();
		s.writeInt(getStyle());
	}


	/**
	 * Scrolls the text component that contains this caret so that this
	 * caret is visible.  This operation is wrapped in a
	 * <code>Runnable</code> so that it is threadsafe.
	 */
	class SafeScroller implements Runnable {
	
		private Rectangle r;

		SafeScroller(Rectangle r) {
			this.r = r;
		}

		public void run() {
			if (component != null)
				component.scrollRectToVisible(r);
		}

	}



	/**
	 * Handles many events from this caret.
	 */
	class Handler implements PropertyChangeListener, DocumentListener,
							ActionListener, ClipboardOwner {

		/**
		 * Invoked when the blink timer fires.  This is called
		 * asynchronously.  The simply changes the visibility
		 * and repaints the rectangle that last bounded the caret.
		 *
		 * @param e the action event
		 */
		public void actionPerformed(ActionEvent e) {
			if (width == 0 || height == 0) {
				// setVisible(true) will cause a scroll, only do this if the
				// new location is really valid.
				if (component != null) {
					TextUI mapper = component.getUI();
					try {
						Rectangle r = mapper.modelToView(component, dot);
						if (r!=null && r.width!=0 && r.height!=0) {
							validateWidth(r);
							damage(r);
						}
					} catch (BadLocationException ble) {
					}
				}
			}
			visible = !visible;
			repaint();
		}

		/**
		 * Updates the dot and mark if they were changed by
		 * the insertion.
		 *
		 * @param e the document event
		 * @see DocumentListener#insertUpdate
		 */
		public void insertUpdate(DocumentEvent e) {

			if (!SwingUtilities.isEventDispatchThread()) {
				if ((e.getOffset() <= dot || e.getOffset() <= mark)
						&& selectionTag != null) {
					try {
						component.getHighlighter().changeHighlight(selectionTag, 
								Math.min(dot, mark), Math.max(dot, mark));
					} catch (BadLocationException e1) {
						e1.printStackTrace();
					}
				}
				return;
			}
	
			int offset = e.getOffset();
			int length = e.getLength();
			int newDot = dot;
			short changed = 0;
	
			if (component.inUndoRedo()) {
				setDot(offset + length);
				return;
			}

			if (newDot >= offset) {
				newDot += length;
				changed |= 1;
			}
			int newMark = mark;
			if (newMark >= offset) {
				newMark += length;
				changed |= 2;
			}
	
			if (changed != 0) {
				if (newMark == newDot) {
					setDot(newDot);
					ensureValidPosition();
				} 
				else {
					setDot(newMark);
					if (getDot() == newMark) {
						// Due this test in case the filter vetoed the
						// change in which case this probably won't be
						// valid either.
						moveDot(newDot);
					}
					ensureValidPosition();
				}
			}

		}

		/**
		 * Updates the dot and mark if they were changed
		 * by the removal.
		 *
		 * @param e the document event
		 * @see DocumentListener#removeUpdate
		 */
		public void removeUpdate(DocumentEvent e) {

			if (!SwingUtilities.isEventDispatchThread()) {
				int length = component.getDocument().getLength();
				dot = Math.min(dot, length);
				mark = Math.min(mark, length);
				if ((e.getOffset() < dot || e.getOffset() < mark) 
						&& selectionTag != null) {
					try {
						component.getHighlighter().changeHighlight(selectionTag, 
								Math.min(dot, mark), Math.max(dot, mark));
					} catch (BadLocationException e1) {
						e1.printStackTrace();
					}
				}
				return;
			}

			int offs0 = e.getOffset();
			int offs1 = offs0 + e.getLength();
			int newDot = dot;
			int newMark = mark;

			if(component.inUndoRedo()) {
				setDot(offs0);
				return;
			}

			if (newDot >= offs1)
				newDot -= (offs1 - offs0);
			else if (newDot >= offs0)
				newDot = offs0;

			if (newMark >= offs1)
				newMark -= (offs1 - offs0);
			else if (newMark >= offs0)
				newMark = offs0;

			if (newMark == newDot) {
				forceCaretPositionChange = true;
				try {
					setDot(newDot);
				} finally {
					forceCaretPositionChange = false;
				}
				ensureValidPosition();
			}
			else {
				setDot(newMark);
				if (getDot() == newMark) {
					// Due this test in case the filter vetoed the change
					// in which case this probably won't be valid either.
					moveDot(newDot);
				}
				ensureValidPosition();
			}

		}

		/**
		 * Gives notification that an attribute or set of attributes changed.
		 *
		 * @param e the document event
		 * @see DocumentListener#changedUpdate
		 */
		public void changedUpdate(DocumentEvent e) {
			if (!SwingUtilities.isEventDispatchThread())
				return;
			if(component.inUndoRedo())
				setDot(e.getOffset() + e.getLength());
		}

		/**
		 * This method gets called when a bound property is changed.
		 * We are looking for document changes on the editor.
		 */
		public void propertyChange(PropertyChangeEvent evt) {
			Object oldValue = evt.getOldValue();
			Object newValue = evt.getNewValue();
			if ((oldValue instanceof Document) || (newValue instanceof Document)) {
				setDot(0);
				if (oldValue != null)
					((Document)oldValue).removeDocumentListener(this);
				if (newValue != null)
					((Document)newValue).addDocumentListener(this);
			}
			else if("enabled".equals(evt.getPropertyName())) {
				Boolean enabled = (Boolean) evt.getNewValue();
				if(component.isFocusOwner()) {
					if(enabled == Boolean.TRUE) {
						if(component.isEditable())
							setVisible(true);
						setSelectionVisible(true);
					}
					else {
						setVisible(false);
						setSelectionVisible(false);
					}
				}
			}
		}

		/**
		 * Toggles the visibility of the selection when ownership is lost.
		 */
		public void lostOwnership(Clipboard clipboard,
								Transferable contents) {
			if (ownsSelection) {
				ownsSelection = false;
				if (component != null && !component.hasFocus())
					setSelectionVisible(false);
			}
		}

	}


	/**
	 * Filter bypass for this caret class.
	 */
	private class DefaultFilterBypass extends NavigationFilter.FilterBypass {

		public Caret getCaret() {
			return ConfigurableCaret.this;
		}

		public void setDot(int dot, Position.Bias bias) {
			handleSetDot(dot);
		}

		public void moveDot(int dot, Position.Bias bias) {
			handleMoveDot(dot);
		}

	}


}